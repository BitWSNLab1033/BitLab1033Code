#ifndef BEACON_H
#define BEACON_H 

enum {
  AM_BEACON = 6   //任务包的发送组号，参赛队需采用该组号才可接收到任务包
};

typedef nx_struct BeaconMsg {  //任务包结构体
  nx_uint16_t serialnumber;
  nx_uint8_t  data[28];
} BeaconMsg;

//广播距离发送任务包时间的数据包结构体
typedef nx_struct NoticeMsg {
  nx_uint16_t remaintime;  //距离发送任务包时间

} NoticeMsg;

#endif
