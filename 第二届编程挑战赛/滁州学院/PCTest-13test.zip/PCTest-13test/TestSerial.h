
#ifndef TEST_SERIAL_H
#define TEST_SERIAL_H


typedef nx_struct BlinkToRadioMsg {
	nx_uint16_t  tagid;
  	nx_uint16_t  tagdata;
  	nx_uint16_t  hint;

}BlinkToRadioMsg;

typedef nx_struct test_serial_msg {
  nx_uint8_t  comtype;
  nx_uint16_t value;
} test_serial_msg_t;

typedef nx_struct test_radio_msg {
  nx_uint8_t  comtype;
  nx_uint16_t value;
  nx_uint16_t counter;
} test_radio_msg_t;

//00 01 00 78 00 03 9F EE
typedef nx_struct test_return_msg {
  nx_uint8_t xx1;
  nx_uint8_t xx2;
  nx_uint8_t xx3;
  nx_uint8_t xx4;
  nx_uint8_t xx5;
  nx_uint8_t xx6;
  nx_uint8_t xx7;
  nx_uint8_t xx8;

  nx_uint16_t source;
  nx_uint16_t seqno;
  nx_uint16_t parent;
  nx_uint16_t metric;
  nx_uint8_t  data;
  nx_uint16_t hopcount;
  nx_uint16_t sendcount;
  nx_uint16_t counter;
} test_return_msg_t;



enum {
  AM_TEST_SERIAL_MSG = 0xEE,
//id=6
};

#endif
