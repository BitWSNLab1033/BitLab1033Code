// $Id: BlinkToRadio.h,v 1.4 2006/12/12 18:22:52 vlahan Exp $

#ifndef BLINKTORADIO_H
#define BLINKTORADIO_H

typedef nx_struct test_serial_msg {
   nx_uint8_t  comtype;
   nx_uint16_t value;
   nx_uint16_t counter;
} test_radio_msg_t;
typedef nx_struct test_return_msg {
  nx_uint8_t xx1;
  nx_uint8_t xx2;
  nx_uint8_t xx3;
  nx_uint8_t xx4;
  nx_uint8_t xx5;
  nx_uint8_t xx6;
  nx_uint8_t xx7;
  nx_uint8_t xx8;

  nx_uint16_t source;
  nx_uint16_t seqno;
  nx_uint16_t parent;
  nx_uint16_t metric;
  nx_uint8_t  data;
  nx_uint16_t hopcount;
  nx_uint16_t sendcount;
  nx_uint16_t counter;
} test_return_msg_t;

enum {
  AM_TEST_SERIAL_MSG = 0xEE,
};

#endif
